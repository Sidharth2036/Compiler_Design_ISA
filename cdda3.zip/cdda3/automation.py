def identify_parallel_loops(code):
    # For simplicity, assume the outer two loops are parallelizable
    parallel_loops = []
    for line in code.split('\n'):
        if 'for' in line:
            parallel_loops.append(line.strip())
    return parallel_loops

def represent_in_three_address(parallel_loops):
    three_address_code = []
    for loop in parallel_loops:
        # Simplified representation for demonstration
        if 'i' in loop:
            three_address_code.append("i = 0")
            three_address_code.append("L1: if i >= 2 goto L2")
        elif 'j' in loop:
            three_address_code.append("j = 0")
            three_address_code.append("L3: if j >= 2 goto L4")
    three_address_code.append("C[i][j] = 0")
    three_address_code.append("k = 0")
    three_address_code.append("L5: if k >= 2 goto L6")
    three_address_code.append("C[i][j] = C[i][j] + A[i][k] * B[k][j]")
    three_address_code.append("k = k + 1")
    three_address_code.append("goto L5")
    three_address_code.append("L6: j = j + 1")
    three_address_code.append("goto L3")
    three_address_code.append("L4: i = i + 1")
    three_address_code.append("goto L1")
    three_address_code.append("L2: end")
    return three_address_code

def convert_to_custom_isa(three_address_code):
    custom_isa = []
    for line in three_address_code:
        if "i = 0" in line:
            custom_isa.append("LOAD R1, 0")
        elif "j = 0" in line:
            custom_isa.append("LOAD R2, 0")
        elif "C[i][j] = 0" in line:
            custom_isa.append("STORE 0, C[R1][R2]")
        elif "k = 0" in line:
            custom_isa.append("LOAD R3, 0")
        elif "C[i][j] = C[i][j] + A[i][k] * B[k][j]" in line:
            custom_isa.append("MUL R4, A[R1][R3], B[R3][R2]")
            custom_isa.append("ADD C[R1][R2], C[R1][R2], R4")
        elif "k = k + 1" in line:
            custom_isa.append("ADD R3, R3, 1")
        elif "j = j + 1" in line:
            custom_isa.append("ADD R2, R2, 1")
        elif "i = i + 1" in line:
            custom_isa.append("ADD R1, R1, 1")
        elif "goto" in line:
            custom_isa.append(line.replace("goto", "JMP"))
        elif "if" in line:
            custom_isa.append(line.replace("if", "CMP").replace("goto", "JGE"))
    custom_isa.append("L2: HALT")
    return custom_isa

# Example matrix multiplication code
code = """
void multiply(int A, int B, int C) {
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            C[i][j] = 0;
            for (int k = 0; k < 2; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}
"""

# Identify parallel loops
parallel_loops = identify_parallel_loops(code)

# Represent loops in three-address code
three_address_code = represent_in_three_address(parallel_loops)

# Convert to custom ISA
custom_isa = convert_to_custom_isa(three_address_code)

# Print results
print("Parallel Loops:")
for loop in parallel_loops:
    print(loop)

print("\nThree-Address Code:")
for line in three_address_code:
    print(line)

print("\nCustom ISA:")
for line in custom_isa:
    print(line)

