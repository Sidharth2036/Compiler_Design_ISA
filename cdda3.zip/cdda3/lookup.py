class Instruction:
    def __init__(self, opcode, operation, operands, description):
        self.opcode = opcode
        self.operation = operation
        self.operands = operands
        self.description = description

class LookupTable:
    def __init__(self):
        self.table = []

    def add_instruction(self, opcode, operation, operands, description):
        instruction = Instruction(opcode, operation, operands, description)
        self.table.append(instruction)

    def print_lookup_table(self):
        print("Lookup Table:")
        print(f"{'Opcode':^8} | {'Operation':^15} | {'Operands':^20} | {'Description':^30}")
        print("-" * 80)
        for instruction in self.table:
            print(f"{instruction.opcode:^8} | {instruction.operation:^15} | {instruction.operands:^20} | {instruction.description:^30}")

def main():
    lookup_table = LookupTable()

    # Custom ISA Instructions
    lookup_table.add_instruction("LOAD", "Load immediate", "R1, 0", "Load a value into a register")
    lookup_table.add_instruction("STORE", "Store value", "0, C[R1][R2]", "Store a value in memory")
    lookup_table.add_instruction("MUL", "Multiply", "R4, A[R1][R3], B[R3][R2]", "Multiply two values and store in a register")
    lookup_table.add_instruction("ADD", "Add", "C[R1][R2], C[R1][R2], R4", "Add two values and store in memory")
    lookup_table.add_instruction("ADD", "Add", "R3, R3, 1", "Increment a register")
    lookup_table.add_instruction("JMP", "Jump", "L1", "Unconditional jump to a label")
    lookup_table.add_instruction("CMP", "Compare", "R1, 2", "Compare a register with a value")
    lookup_table.add_instruction("JGE", "Jump if greater or equal", "L2", "Conditional jump if greater or equal")
    lookup_table.add_instruction("HALT", "Halt", "", "Stop execution")

    lookup_table.print_lookup_table()

if __name__ == "__main__":
    main()

